from re import findall
import numpy as np
from sklearn.linear_model import LogisticRegression
from sklearn.metrics import roc_auc_score
from sklearn.metrics import f1_score
import pickle as pk
import argparse
import pandas as pd
import os
import json
import random

from utils import dcg_at_k, ndcg_at_k
from data_loader import SENSITIVE_ATTR_DICT  # predefined sensitive attributes for different datasets
from data_loader import DATA_FOLDER, RAW_FOLDER


def sigmoid(x):
    return 1 / (1 + np.exp(-x))


# load predefined sensitive attributes for pokec data
# csv format for each line: node_idx, gender, region, age
def load_node_attributes_pokec(attribute_file):
    node_attributes = {}
    gender_group = {}
    region_group = {}
    age_group = {}

    with open(attribute_file, 'r') as fin:
        lines = fin.readlines()
        idx = 0
        for line in lines:
            if idx == 0:
                idx += 1
                continue
            eachline = line.strip().split(',')
            node_idx = int(idx-1)
            gender = int(float(eachline[0]))
            region = int(eachline[1])
            age = int(float(eachline[2]))
            node_attributes[node_idx] = (gender, region, age)
            
            if gender not in gender_group:
                gender_group[gender] = []
            gender_group[gender].append(node_idx)

            if region not in region_group:
                region_group[region] = []
            region_group[region].append(node_idx)

            if age not in age_group:
                age_group[age] = []
            age_group[age].append(node_idx)

            idx += 1

    return node_attributes, {'gender':gender_group, 'region':region_group, 'age':age_group}


# load edge for pokec data
# csv format: src_node, dst_node, edge_weight (binary: 1.0)
def load_adjacency_matrix_pokec(file, M):
    adj_mtx = np.zeros((M,M))
    # load the adjacency matrix of size MxM of training or testing set
    print('loading data ...')
    with open(file, 'r') as fin:
        lines = fin.readlines()
        idx = 0 
        for line in lines:
            if idx == 0: 
                idx += 1
                continue
            eachline = line.strip().split(',')
            scr_node = int(eachline[0])
            dst_node = int(eachline[1])
            weight = float(eachline[2])
            adj_mtx[scr_node, dst_node] = weight 
            adj_mtx[dst_node, scr_node] = weight 
            idx += 1
    
    return adj_mtx


# load sensitive attributes for movielens
# dat format: user_idx, gender, age, occupation
def load_user_attributes_movielens(file, M):
    #(gender, age, occupation)
    user_attributes = {}
    gender_dist = {'F':0, 'M':0}
    age_dist = {1:0, 18:0, 25:0, 35:0, 45:0, 50:0, 56:0}
    occupation_dist = {occup:0 for occup in range(21)}

    with open(file, 'r') as fin:
        lines = fin.readlines()
        for line in lines:
            eachline = line.strip().split('::')
            user_idx = int(eachline[0])
            gender = eachline[1]
            age = int(eachline[2])
            occupation = int(eachline[3])
            user_attributes[user_idx] = (gender, age, occupation)

    return user_attributes


# load edges for movielens
# dat format: user_idx, item_idx, rating
def load_rating_matrix_movielens(file, M, N):
    over_rating_sparse_mtx = {}
    over_rating_mtx = np.zeros((M,N))
    #load the overall rating matrices of size MxN of training or testing set
    print('loading data ...')
    with open(file, 'r') as fin:
        lines = fin.readlines()
        for line in lines:
            eachline = line.strip().split('::')
            user_idx = int(eachline[0])
            item_idx = int(eachline[1])
            rating = int(eachline[2])
            over_rating_mtx[user_idx, item_idx] = rating
            over_rating_sparse_mtx[(user_idx, item_idx)] = rating
    
    return over_rating_sparse_mtx, over_rating_mtx


def eval_unbiasedness_pokec(data_name, embed_file=None):  # if file is none, then evalueate random embedding
    
    if data_name == 'pokec-z': M = 67796 
    elif data_name == 'pokec-n': M = 66569 
    else: raise Exception('Invalid dataset!')
    
    node_attributes, attr_groups = load_node_attributes_pokec('{}/{}_node_attribute.csv'.format(DATA_FOLDER, data_name))
    adj_mtx = load_adjacency_matrix_pokec('{}/{}_edge.csv'.format(DATA_FOLDER, data_name), M)
    
    genders = np.array([node_attributes[i][0] for i in range(M)])
    regions = np.array([node_attributes[i][1] for i in range(M)])
    ages = np.array([node_attributes[i][2] for i in range(M)])
    
    print(genders)

    attribute_labels = {'gender': genders, 'age': ages, 'region': regions}
    
    
    if embed_file:  # learned embeddings loaded from valid file
        embedding = pk.load(open(embed_file, 'rb'))
    else: # random embeddings
        embedding = np.random.rand(*(M,16))
    
    results = {
        'unbiasedness': {
            'gender': 0.0, 
            'age': 0.0, 
            'region': 0.0
        },
        'fairness-DP':{
            'gender': 0.0, 
            'age': 0.0, 
            'region': 0.0
        },
        'fairness-EO':{
            'gender': 0.0, 
            'age': 0.0, 
            'region': 0.0
        },
        'utility': 0.0
    }
    
    # eval micro-f1 for attribute prediction (unbiasedness)
    print('Unbiasedness evaluation (predicting attribute)')
    for evaluate_attr in ['gender', 'age', 'region']:
                
        # eval learned embedding
        lgreg = LogisticRegression(random_state=0, class_weight='balanced', max_iter=500).fit(
            embedding[:50000], attribute_labels[evaluate_attr][:50000])
        pred = lgreg.predict(embedding[50000:])
        
        score = f1_score(attribute_labels[evaluate_attr][50000:], pred, average='micro')
        
        print('-- micro-f1 when predicting {}: {}'.format(evaluate_attr, score))
        results['unbiasedness'][evaluate_attr] = score

        
    # eval fairness (DP & EO)
    print('Fairness evaluation (DP & EO)')
    for evaluate_attr in ['gender', 'age', 'region']:
        
        if evaluate_attr == 'age': 
            num_sample_pairs = 200000
            attr_group = attr_groups[evaluate_attr]
            keys = list(attr_group.keys())
            for key in keys:
                if len(attr_group[key]) < 1000:
                    del attr_group[key]
        else:
            num_sample_pairs = 1000000
            attr_group = attr_groups[evaluate_attr]
            
        attr_values = list(attr_group.keys())
        num_attr_value = len(attr_values)
        comb_indices = np.ndindex(*(num_attr_value,num_attr_value))

        DP_list = []
        EO_list = []
        f = open("allPokec_gender_age.csv", "w")
        #f.write("node0,gender0,age0,node1,gender1,age1,score\n")
        count = 0
        for comb_idx in comb_indices:
            group0 = attr_group[attr_values[comb_idx[0]]]
            group1 = attr_group[attr_values[comb_idx[1]]]
            #group0_nodes = np.random.choice(group0, num_sample_pairs, replace=True)
            #group1_nodes = np.random.choice(group1, num_sample_pairs, replace=True)
            # select a few nodes and select 30 neighbors of them and put them in the pairs
            # rest is random few = 10000*30 for other algo select top 10000 only
            group0_nodes = []
            group1_nodes = []
            for node_id in range(M):
              s = random.sample(range(M),20)
              for j in s:
                group0_nodes.append(node_id)
                group1_nodes.append(j)
            pair0_nodes = np.array([group0_nodes])
            pair1_nodes = np.array([group1_nodes])       
            #print(group0_nodes.T.shape)
            #print(group1_nodes.T.shape)

            pair_scores = np.sum(np.multiply(embedding[group0_nodes], embedding[group1_nodes]), axis=1)
            DP_prob = np.sum(sigmoid(pair_scores)) / num_sample_pairs
            DP_list.append(DP_prob)
            if count==0:
              gen0 = np.array([genders[group0_nodes]])
              gen1 = np.array([genders[group1_nodes]])
              reg0 = np.array([regions[group0_nodes]])
              reg1 = np.array([regions[group1_nodes]])
              age0 = np.array([ages[group0_nodes]])
              age1 = np.array([ages[group1_nodes]])
              scores = np.array([pair_scores])
              print(gen0.T.shape,gen1.T.shape, scores.shape)
              data = pd.DataFrame(np.concatenate((pair0_nodes.T, gen0.T, age0.T, pair1_nodes.T, gen1.T, age1.T, scores.T), axis = 1), columns=['node0','gender0','age0','node1','gender1','age1','score'])
              bins =  np.arange(0, 120, 20)
              ind1 = pd.DataFrame(np.digitize(data['age0'], bins), columns = ['age0'])
              ind2 = pd.DataFrame(np.digitize(data['age1'], bins), columns = ['age1'])
              data['age0'] = ind1['age0']
              data['age1'] = ind2['age1']    
              #dataset['age0'] = ind1['age0']
              #dataset['age1'] = ind2['age1']  
              final = data.to_csv("allPokec_gender_age.csv", index = False, header= True)
              LPG(data,adj_mtx)
              print(final)
            comb_edge_indicator = (adj_mtx[group0_nodes, group1_nodes] > 0).astype(int)
            if np.sum(comb_edge_indicator) > 0:
                EO_prob = np.sum(sigmoid(pair_scores.T[0]) * comb_edge_indicator) / np.sum(comb_edge_indicator)
                EO_list.append(EO_prob)
            count = count + 1
        DP_value = max(DP_list) - min(DP_list)
        EO_value = max(EO_list) - min(EO_list)
        
        print('-- DP_value when predicting {}:{}'.format(evaluate_attr, DP_value))
        print('-- EO_value when predicting {}:{}'.format(evaluate_attr, EO_value))
        results['fairness-DP'][evaluate_attr] = DP_value
        results['fairness-EO'][evaluate_attr] = EO_value
            
        
    #evaluate NDCG for link prediction
    k = 10
    accum_ndcg = 0
    node_cnt = 0

    print('Utility evaluation (link prediction)')
    for node_id in range(M):
        node_edges = adj_mtx[node_id]
        pos_nodes = np.where(node_edges>0)[0]
        # num_pos = len(pos_nodes)
        num_test_pos = int(len(pos_nodes) / 10) + 1
        test_pos_nodes = pos_nodes[:num_test_pos]
        num_pos = len(test_pos_nodes)

        if num_pos == 0 or num_pos >= 100:
            continue
        neg_nodes = np.random.choice(np.where(node_edges == 0)[0], 100-num_pos, replace=False)
        all_eval_nodes = np.concatenate((test_pos_nodes, neg_nodes)) 
        all_eval_edges = np.zeros(100)
        all_eval_edges[:num_pos] = 1

        pred_edges = np.dot(embedding[node_id], embedding[all_eval_nodes].T)
        rank_pred_keys = np.argsort(pred_edges)[::-1]
        ranked_node_edges = all_eval_edges[rank_pred_keys]
        ndcg = ndcg_at_k(ranked_node_edges, k)
        accum_ndcg += ndcg

        node_cnt += 1

    score = accum_ndcg/node_cnt
    print('-- ndcg of link prediction:{}'.format(score))
    results['utility'] = score
    
    return results

#here only I would write the LP code
#what do I need for LP, scores and beta (may be)
#no sorting no nothing


##def LPG(data, scores):  #do for both intersectional and independent
# only thing needed is sensitive data info
# i.e. (gender,age,gender,age) for every pair and corresponding P_uv
# I have to first group them into interesectional groups
# like we did before



#NG
import time
#import gurobipy as gp
#from gurobipy import GRB
#have to figure out what is the data
#what is a intersectional group age x gender x age x gender
#what is a overlapping group in case of graphs
#overlapping happens when there is an edge which is 
#(male,male) edge as well as (reg1,reg2) edge then what
# should be P_uv
#intersectional is non overlapping LP is needed for overlapping
#which is the independent case
# variable X_{uv} u and v are node ids but we want to force
#for every pair there is a variable 
#what is data every m-m m-f f-m and so on
# constrainsts


import pulp as p 
import math 
def LPG(data,adj_mtx):     #here we are taking two sensitive attrib # make the data here  
    m = 40 # total 40 groups are there 
    n = len(data)
    data1 = np.zeros((m,n))
    for i in range(len(data)):
        for j in range(2):
          for k in range(2):
            if data.iloc[i,1]==j and data.iloc[i,4]==k :
              data1[2*j+k][i] = 1
             
        for j in range(6):
          for k in range(6):
            if data.iloc[i,2]==j and data.iloc[i,5]==k :
              data1[6*j+k+4][i] = 1   #begins at 4

    print("data is")
    print(data1)
    print(m,n)
    
    

    ############### #  SORTED for ACCURACY ONLY ####
    m=40
    h1=[]
    key1=[]
    cost=np.zeros(n,dtype=int)
    data2=np.zeros((m,n),dtype=int)
    '''
    for i in range(n):
            h1.append(e[i][1])
            key1.append(i)

        
#print(hc)
#     print(key1)
    
    for i in range(1,len(h1)):
        for j in range(i,0,-1):
            var=0
            var2=0
            if h1[j-1]<h1[j]:
                index=j
                var=h1[j]
                h1[j]=h1[j-1]
                h1[j-1]=var

                var2=key1[j]
                key1[j]=key1[j-1]
                key1[j-1]=var2
            else:
                break
    

    
    
    for j in range(len(key1)):    
         data2[0][key1[j]]=j+1
    
    for j in range(n):
        summ=0
        summ=summ+data2[0][j] 
        cost[j]=summ
    '''  
    Lp_prob = p.LpProblem('Problem', p.LpMaximize)  
    solver = p.getSolver('PULP_CBC_CMD', timeLimit=20)
   
    
#     X=np.zeros(n+1,dtype=p.LpVariable)
    X=np.zeros(n+m+1,dtype=p.LpVariable)
    Y=np.zeros(m,dtype=p.LpVariable)
    
    sizes=np.zeros(m,dtype=int)
#     report_index(index,data1,e):  
    max_size=0
    for i in range(m):
        count=0
        for j in range(n):
            if data1[i][j]==1:
                count=count+1 
        if count>max_size:
            max_size=count
        sizes[i]=count
    print(sizes)    
    #############################33
    
  

    beta_actual = []
    for i in range(m):
      beta_actual.append(0.302)
      
    ###############################
    #beta_actual = [0.30355010313755293, 0.10743801652892562, 0.252269224182223, 0.13278688524590163, 0.3118811881188119, 0.1, 0.13043478260869565]



    
    
    select_sizes=np.zeros(m,dtype=int)
   
    size_final=np.zeros(m,dtype=int)

    for i in range(m):
        var1 = str(n+100+i)
        Y[i]=p.LpVariable(var1,lowBound=0,upBound=1,cat='Continuous')
    
    for i in range(n):
        var1=str(i)       
        X[i]=p.LpVariable(var1,lowBound=0,upBound=1,cat='Continuous')
   
    X[n]=p.LpVariable(str(n),lowBound=0,upBound=1,cat='Continuous')  

    #tpr = p.LpVariable(str(n+200),lowBound=0,upBound=1,cat='Continuous')  
    #fpr = p.LpVariable(str(n+201),lowBound=0,upBound=1,cat='Continuous')  

#     for i in range(m):
#         k=n+i+1
#         var1=str(k)     
#         alpha=(((sizes[i])*(sizes[i]+1))/2)
#         X[i]=p.LpVariable(var1,lowBound=(((beta*sizes[i])*(beta*sizes[i]+1))/2),upBound=alpha,cat='Continuous')
    
        
#     X[n]=  p.LpVariable("z1",lowBound=0)
    #X[n+1]=  p.LpVariable("z2",lowBound=0)
  

    #########objective function#####################
    
#     Lp_prob += 2*X[n+1]+10*X[n+2]+9*X[n+3]+3*X[n+4]
    #alpha=0.8
    #beta_avg = 0.10
    Lp_prob+= p.lpSum([(X[j])*data.iloc[j,6] for j in range(n)]) 
    #Lp_prob+=1  
    
    #Lp_prob += Y[0]*sizes[0] + Y[1]*sizes[1] >= p.lpSum([Y[j]*sizes[j] for j in np.arange(2,6)])
    #Lp_prob += Y[0]*sizes[0] + Y[1]*sizes[1] <= p.lpSum([Y[j]*sizes[j] for j in np.arange(2,6)])
    
    ##############constraint#################
    #first select the  the number of make female in test data
    #then apply the equalized odd constraints assuming 
    #look at all males which have been predicted positve/and all the females predicted negative
    F_test = 0
    M_test = 0
        
    #for i in range(len(y_test)):
    #    if(data1[0][i]==1 and y_test.iloc[i]==1):
    #        M_test= M_test+1
    #    elif(data1[1][i]==1 and y_test.iloc[i]==1):
    #        F_test= F_test+1
    test_count = np.zeros(m, dtype = int)
    '''
    for i in range(len(y_test)):
      for j in range(m): 
        if(data1[j][i]==1 and y_test_pred[i]==1):
            test_count[j] = test_count[j] +1
    '''            
    
    #Lp_prob += (p.lpSum([(X[j])*(data1[0][j])*y_test_pred[j] for j in range(n) if y_test_pred[j]==1])/M_test) <= (p.lpSum([(X[j])*(data1[1][j])*y_test_pred[j] for j in range(n) if y_test_pred[j]==1])/F_test) + 0.0009
    #Lp_prob += (p.lpSum([(X[j])*(data1[0][j])*(1-y_test_pred[j]) for j in range(n) if y_test_pred[j]==0])/(sizes[0]-M_test)) <= (p.lpSum([(X[j])*(data1[1][j])*(1-y_test_pred[j]) for j in range(n) if y_test_pred[j]==0])/(sizes[1]-F_test))+ 0.0009
    
    '''
    for i in range(m):   #TPR constraints
      Lp_prob += (1/test_count[i])*p.lpSum([(X[j])*(data1[i][j])*y_test_pred[j] for j in range(n) if (y_test_pred[j]==1) ]) >= tpr 
      Lp_prob += (1/test_count[i])*p.lpSum([(X[j])*(data1[i][j])*y_test_pred[j] for j in range(n) if (y_test_pred[j]==1 )]) <= tpr + 0.01
    for i in range(m):    #FPR constraints
      Lp_prob += (1/(sizes[i]-test_count[i]))*p.lpSum([(X[j])*(data1[i][j])*(1-y_test_pred[j]) for j in range(n) if (y_test_pred[j]==0)]) >= fpr
      Lp_prob += (1/(sizes[i]-test_count[i]))*p.lpSum([(X[j])*(data1[i][j])*(1-y_test_pred[j]) for j in range(n) if (y_test_pred[j]==0)]) <= fpr + 0.01
    '''
    #Lp_prob += F_test*p.lpSum([(X[j])*(data1[0][j])*y_test_pred[j] for j in range(n) if (y_test_pred[j]==1) ]) <= M_test*p.lpSum([(X[j])*(data1[1][j])*y_test_pred[j] for j in range(n) if (y_test_pred[j]==1 )]) + 0.004
    #Lp_prob += (sizes[1]-F_test)*p.lpSum([(X[j])*(data1[0][j])*(1-y_test_pred[j]) for j in range(n) if (y_test_pred[j]==0)]) <= (sizes[0]-M_test)*p.lpSum([(X[j])*(data1[1][j])*(1-y_test_pred[j]) for j in range(n) if (y_test_pred[j]==0 )]) + 0.004
    


    #Lp_prob += F_test*p.lpSum([(X[j])*(data1[0][j])*y_test_pred[j] for j in range(n) if (y_test_pred[j]==1 and y_test.iloc[j]==1) ]) <= M_test*p.lpSum([(X[j])*(data1[1][j])*y_test_pred[j] for j in range(n) if (y_test_pred[j]==1 and y_test.iloc[j]==1)]) + 0.01
    #Lp_prob += (sizes[1]-F_test)*p.lpSum([(X[j])*(data1[0][j])*(1-y_test_pred[j]) for j in range(n) if (y_test_pred[j]==0 and y_test.iloc[j]==0)]) <= (sizes[0]-M_test)*p.lpSum([(X[j])*(data1[1][j])*(1-y_test_pred[j]) for j in range(n) if (y_test_pred[j]==0 and y_test.iloc[j]==0)]) + 0.01
    
    #Lp_prob += p.lpSum([(X[j])*(data1[0][j])*y_test.iloc[j] for j in range(n) if y_test.iloc[j]==1])/M_test <= p.lpSum([(X[j])*(data1[1][j])*y_test.iloc[j] for j in range(n) if y_test.iloc[j]==1])/F_test + 0.004
    #Lp_prob += (sizes[1]-F_test)*p.lpSum([(X[j])*(data1[0][j])*(1-y_test.iloc[j]) for j in range(n) if y_test.iloc[j]==0])/M_test <= (sizes[0]-M_test)*p.lpSum([(X[j])*(data1[1][j])*(1-y_test.iloc[j]) for j in range(n) if y_test.iloc[j]==0])/F_test + 0.004
    
    for i in range(m):
      #  if i<m:
            Lp_prob += p.lpSum([(X[j])*(data1[i][j]) for j in range(n)]) >= Y[i]*sizes[i]
            Lp_prob += p.lpSum([(X[j])*(data1[i][j]) for j in range(n)]) <= (Y[i]+0.01)*sizes[i]
    
    beta_avg = 0.5
    alpha = 0
    for i in range(m):
        if beta_actual[i] >= beta_avg:
            Lp_prob += Y[i] >= (1-alpha)*beta_actual[i] + alpha*beta_avg
            Lp_prob += Y[i] <= beta_actual[i]
        else:
            Lp_prob += Y[i] >= (1-alpha)*beta_actual[i] + alpha*beta_avg
            Lp_prob += Y[i] <= beta_avg 
    
           
    #Lp_prob+= p.lpSum([(X[j])*cost[j] for j in range(n)])>=100
        
    #####################################
    #solver = p.CPLEX_PY()
    #solver.buildSolverModel(Lp_prob)
    #Lp_prob.solverModel.parameters.timelimit.set(60)
    #solver.callSolver(P)
    #status = solver.findSolutionValues(Lp_prob)
    #################################################################
    status = Lp_prob.solve(solver)   # Solver 
    print(p.LpStatus[status]) 
    print("objective is:")        
    print(p.value(Lp_prob.objective))
    print("discripency is:") 
    print(p.value(X[n]))
    x=np.zeros(n,dtype=float)

   # The solution status 
    Synth1={}
    Synth2={}
    # # Printing the final solution
    ## compute accuracy, new DP and old DP and NDCG
    count1 = 0
    count2 = 0
    count3 = 0

    fair_scores = []
    for i in range(n):
      fair_scores.append(p.value(X[i]))
      if fair_scores[i]==1.0: count1 = count1 + 1
      elif fair_scores[i]==0.0: count2 = count2 + 1
      else: count3 = count3 + 1

    print(count1,count2,count3)
    print(np.array(fair_scores))
    print(data['score'].to_numpy())
    
    gr = [ [] for _ in range(m) ]
    grf= [ [] for _ in range(m) ]
      
    #count = np.zeros(r, dtype=int)
      
    DP_list = []
    DPf_list = []
    
    for i in range(n):
          for j in range(2):
            for k in range(2):
              if data.iloc[i,1] == j and data.iloc[i,3] == k:
                gr[2*j+k].append(data.iloc[i,6])
                grf[2*j+k].append(fair_scores[i])
                        
          for j in range(6):
            for k in range(6):
              if data.iloc[i,2]==j and data.iloc[i,5]==k :
                gr[6*j+k+4].append(data.iloc[i,6])   #begins at 4
                gr[6*j+k+4].append(fair_scores[i])

    for i in range(m):
      if sizes[i] != 0:
        DP_list.append(np.sum(sigmoid(np.asarray(gr[i])))/sizes[i])
        DPf_list.append(np.sum(sigmoid(np.asarray(grf[i])))/sizes[i])

    DP = max(DP_list)-min(DP_list)
    DPf = max(DPf_list)-min(DPf_list)
    print("Demogrphic Parity is without/with fair", DP, DPf)
    
    M = 67796
    k = 10
    accum_ndcg = 0
    node_cnt = 0
    accum_ndcg_u = 0
    node_cnt_u = 0    
    adj_mtx_fair = np.zeros((M,M))
    #adj_mtx_unfair = np.zeros((M,M))
    selected_pairs = np.zeros((M,M))

    for i in range(n):
        #adj_mtx_unfair[int(data.iloc[i,0])][int(data.iloc[i,3])] = data.iloc[i,6]
        selected_pairs[int(data.iloc[i,0])][int(data.iloc[i,3])] = 1
        adj_mtx_fair[int(data.iloc[i,0])][int(data.iloc[i,3])] = fair_scores[i]

    #print(adj_mtx_fair)
    #print(np.count_nonzero(adj_mtx_fair))
    print('Utility evaluation (link prediction)')
    s = random.sample(range(M),10000)
    for node_id in s:
        node_edges = adj_mtx[node_id]
        test_pos_nodes = []
        neg_nodes = []
        for i in range(M):
            if selected_pairs[node_id][i]==1:
                 if adj_mtx[node_id][i]>0:
                     test_pos_nodes.append(i)
                 else:
                     neg_nodes.append(i)
 
        #pred_edges_fair.append(adj_mtx_fair[node_id][i])
        #pred_edges_unfair.append(adj_mtx_fair[node_id][i])

        #pos_nodes = np.where(node_edges>0)[0]
        #num_pos = len(pos_nodes)
        #num_test_pos = int(len(pos_nodes) / 10) + 1
        #test_pos_nodes = pos_nodes[:num_test_pos]
        #num_pos = len(test_pos_nodes)
        #print(num_pos)

        #if num_pos == 0 or num_pos >= 100:
        #    continue
        #neg_nodes = np.random.choice(np.where(node_edges == 0)[0], 100-num_pos, replace=False)
        num_pos = len(test_pos_nodes)
        all_eval_nodes = np.concatenate((test_pos_nodes, neg_nodes)) 
        all_eval_edges = np.zeros(20)  # because each node has 20 neighbors in the set


        all_eval_edges[:num_pos] = 1
        #print(all_eval_edges)

       
        #in pred_edges all positive edges should be before and then negative edge sores
        edges = []
        pred_edges_fair_pos = []
        pred_edges_fair_neg = []

        #pred_edges_unfair_pos = []
        #pred_edges_unfair_neg = []

        for i in range(M):
            if selected_pairs[node_id][i]==1:
                 if adj_mtx[node_id][i]>0:
                     pred_edges_fair_pos.append(adj_mtx_fair[node_id][i])
                     #pred_edges_unfair_pos.append(adj_mtx_unfair[node_id][i])
                 else:
                     pred_edges_fair_neg.append(adj_mtx_fair[node_id][i])
                     #pred_edges_unfair_neg.append(adj_mtx_unfair[node_id][i])

        #print(pred_edges_fair_pos)
        pred_edges_fair = np.concatenate((np.array(pred_edges_fair_pos),np.array(pred_edges_fair_neg)))
        pred_edges_unfair = np.concatenate((np.array(pred_edges_unfair_pos),np.array(pred_edges_unfair_neg)))
      
        #print(len(pred_edges_unfair))
        #print(len(pred_edges_fair))

        '''
        if len(pred_edges_unfair) >=k:
            #pred_edges_unfair = np.array(pred_edges_unfair)
            rank_pred_keys = np.argsort(pred_edges_unfair)[::-1]
            ranked_node_edges = all_eval_edges[rank_pred_keys]
            ndcg_u = ndcg_at_k(ranked_node_edges, k)
            if ndcg_u != 0.0:
                 accum_ndcg_u += ndcg_u
                 print(ndcg_u, node_cnt_u)
                 node_cnt_u += 1
        ''' 
        if len(pred_edges_fair) >=k:
            #pred_edges_fair = np.array(pred_edges_fair)
            rank_pred_keys = np.argsort(pred_edges_fair)[::-1]
            ranked_node_edges = all_eval_edges[rank_pred_keys]
            ndcg = ndcg_at_k(ranked_node_edges, k)
            if ndcg != 0.0:
                 accum_ndcg += ndcg
                 node_cnt += 1

    score = accum_ndcg/node_cnt
    #score_u = accum_ndcg_u/node_cnt_u

    # now compute accuracy as well and dp

    print('-- ndcg of link prediction for LP score:{}'.format(score))
    #print('-- ndcg of link prediction for unfair score:{}'.format(score_u))
    
    


    '''
    for i in range(n):
        if(p.value(X[i])==1):
            Synth1[i]=1 
            Synth2[i]=-1
#             if(data1[2][i]==1):
#                 print("no")
        else:
            Synth1[i]=-1
            Synth2[i]=1
    Synthu1=Synth1  
    Synthu2=Synth2  
    '''  
    

def eval_unbiasedness_movielens(data_name, embed_file=None):
    
    M = 6040 + 1
    N = 3952 + 1
        
    rating_sparse_mtx, rating_mtx = load_rating_matrix_movielens('{}/ml-1m/ratings.dat'.format(RAW_FOLDER), M, N)
    user_attributes = load_user_attributes_movielens('{}/ml-1m/users.dat'.format(RAW_FOLDER), M)

    genders = np.array([int(user_attributes[i][0]=='M') for i in range(1, M)])
    ages = np.array([int(user_attributes[i][1]) for i in range(1, M)])
    occupations = np.array([int(user_attributes[i][2]) for i in range(1, M)])

    attribute_labels = {'gender': genders, 'age': ages, 'occupation': occupations}

    rating_mtx = rating_mtx[1:]
    rating_mtx = rating_mtx[:,1:]
    
    if embed_file:
        unbiased_embedding = pk.load(open(embed_file,'rb')) 
        X = unbiased_embedding[:M-1]  # users
        Y = unbiased_embedding[M-1:]  # items
    else:
        X, Y = np.random.rand(*(M-1,16)), np.random.rand(*(N-1,16))
    
    results = {
        'unbiasedness': {
            'gender': 0.0, 
            'age': 0.0, 
            'region': 0.0
        },
        # 'fairness-DP':{
        #     'gender': 0.0, 
        #     'age': 0.0, 
        #     'region': 0.0
        # },
        # 'fairness-EO':{
        #     'gender': 0.0, 
        #     'age': 0.0, 
        #     'region': 0.0
        # },
        'utility': 0.0
    }

    # eval micro-f1 for attribute prediction (unbiasedness)
    print('Unbiasedness evaluation (predicting attribute)')
    for evaluate_attr in ['gender', 'age', 'occupation']:
        
        lgreg = LogisticRegression(random_state=0, class_weight='balanced', max_iter=1000).fit(
            X[:5000], attribute_labels[evaluate_attr][:5000])
        pred = lgreg.predict(X[5000:])

        # rating_lgreg = LogisticRegression(random_state=0, class_weight='balanced', max_iter=1000).fit(
        #     rating_mtx[:5000], attribute_labels[evaluate_attr][:5000])
        # rating_pred = rating_lgreg.predict(rating_mtx[5000:])
        
        score = f1_score(attribute_labels[evaluate_attr][5000:], pred, average='micro')
        
        print('-- micro-f1 when predicting {}: {}'.format(evaluate_attr, score))
        results['unbiasedness'][evaluate_attr] = score
        
        # score = f1_score(attribute_labels[evaluate_attr][5000:], rating_pred, average='micro')
        # print('-- raw rating micro-f1: ', score)


    #evaluate NDCG
    k = 10
    accum_ndcg = 0
    
    print('Utility evaluation (link prediction)')
    for user_id in range(1, M):
        user = user_id - 1
        user_ratings = rating_mtx[user] # (rating_mtx[user] > 0).astype(int)
        
        pred_ratings = np.dot(X[user], Y.T)
        rank_pred_keys = np.argsort(pred_ratings)[::-1]
        ranked_user_ratings = user_ratings[rank_pred_keys]
        ndcg = ndcg_at_k(ranked_user_ratings, k)
        accum_ndcg += ndcg
        
    score = accum_ndcg/M
    print('-- ndcg of link prediction:{}'.format(score))
    results['utility'] = score

    return results


# evalute embeddings by batch of files
if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    
    parser.add_argument('--embedding_folder', type=str, default="./embeddings", help='embedding folder path')
    parser.add_argument('--dataset', type=str, default="pokec-z", help='dataset to evaluate')

    args = parser.parse_args()

    # evaluate the performance of all embeddings under a folder
    files = [f for f in os.listdir(args.embedding_folder) 
            if os.path.isfile(os.path.join(args.embedding_folder, f)) and args.dataset+'_' in f]
    files.sort()
    
    output_folder = args.embedding_folder + '_eval_results'
    os.makedirs(output_folder, exist_ok=True)

    for file in files:
        embed_file = os.path.join(args.embedding_folder, file)
        
        print ('=== Evaluating {} ==='.format(embed_file))
        
        if args.dataset == 'movielens':
            results = eval_unbiasedness_movielens(args.dataset, embed_file)
        else: # pokec
            results = eval_unbiasedness_pokec(args.dataset,  embed_file)
        
        output_path = os.path.join(output_folder, file.split('.')[0]+'.txt')
        with open(output_path, 'w') as fp:
            json.dump(results, fp)
